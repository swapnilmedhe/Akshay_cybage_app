var express = require("express");
var db = require("../db/database");
var Budget = require("../domain/budget"); 
const router = express.Router();
 
//handles url http://localhost:6001/products
router.get("/", (req, res, next) => {
 
    db.query(Budget.getAllBudgetSQL(), (err, data)=> {
        if(!err) {
            res.status(200).json({
                message:"Success",
                budgetData:data
            });
        }
    });    
});

router.post("/fetchByDate", (req, res, next) => {

    db.query(Budget.getBudgetByDateSQL(req.body.Selected_date), (err, data)=> {
        if(!err) {
            res.status(200).json({
                message:"Success",
                budgetData:data
            });
        }
    });
        
});
 
//handles url http://localhost:6001/products/add
router.post("/addBudget", (req, res, next) => {
    
    //read product information from request
    let budget = new Budget(req.body.Transaction_date, req.body.Category_id, req.body.Description, req.body.Amount, req.body.IncomeExpense_flag);
 
    db.query(budget.getAddBudgetSQL(), (err, data)=> {
        res.status(200).json({
            message:"Success",
            budgetData: data.insertId
        });
    });
});
 
//handles url http://localhost:6001/products/1001
router.get("/getBudgetDetails/:Budget_id", (req, res, next) => {
    let Budget_id = req.params.Budget_id;
 
    db.query(Budget.getBudgetByIdSQL(Budget_id), (err, data)=> {
        if(!err) {
            if(data && data.length > 0) {
                
                res.status(200).json({
                    message:"Success",
                    budgetData: data
                });
            } else {
                res.status(200).json({
                    message:"Budget Not found."
                });
            }
        } 
    });    
});
 
//handles url http://localhost:6001/products/delete
router.delete("/deleteBudget/:Budget_id", (req, res, next) => {
    var Budget_id = parseInt(req.params.Budget_id);
//    var Budget_id = req.body.Budget_id;
 
    db.query(Budget.deleteBudgetByIdSQL(Budget_id), (err, data)=> {
        if(!err) {
            if(data && data.affectedRows > 0) {
                res.status(200).json({
                    message:`Budget deleted with id = ${Budget_id}.`,
                    budgetData: data.affectedRows
                });
            } else {
                res.status(200).json({
                    message:"Budget Not found."
                });
            }
        } 
    });   
});

router.put("/updatedBudget/:Budget_id", (req, res, next) => {
    var Budget_id = parseInt(req.params.Budget_id);
    let budget = new Budget(req.body.Transaction_date,req.body.Category_id,req.body.Description, req.body.Amount, req.body.IncomeExpense_flag);
 
    db.query(budget.getUpdateBudgetSQL(Budget_id), (err, data)=> {
        if(!err) {
            if(data && data.affectedRows > 0) {
                res.status(200).json({
                    message:`Budget update with id = ${Budget_id}.`,
                    budgetData: data.affectedRows
                });
            } else {
                res.status(200).json({
                    message:"Budget Not found."
                });
            }
        }
    });
});
 
module.exports = router;