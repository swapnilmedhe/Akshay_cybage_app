var express = require("express");
var db = require("../db/database");
var Category = require("../domain/category"); 
const router = express.Router();
 
//handles url http://localhost:6001/products
router.get("/", (req, res, next) => {
 
    db.query(Category.getAllCategorySQL(), (err, data)=> {
        if(!err) {
            res.status(200).json({
                message:"Success",
                categoryData:data
            });
        }
    });    
});
 
//handles url http://localhost:6001/products/add
router.post("/addCategory", (req, res, next) => {
    
    //read product information from request
    let category = new Category(req.body.Category_name, req.body.Category_icon);
 
    db.query(category.getAddCategorySQL(), (err, data)=> {
        res.status(200).json({
            message:"Success",
            categoryData: data.insertId
        });
    });
});
 
//handles url http://localhost:6001/products/1001
router.get("/getCategoryDetails/:Category_id", (req, res, next) => {
    let Category_id = req.params.Category_id;
 
    db.query(Category.getCategoryByIdSQL(Category_id), (err, data)=> {
        if(!err) {
            if(data && data.length > 0) {
                
                res.status(200).json({
                    message:"Success",
                    categoryData: data
                });
            } else {
                res.status(200).json({
                    message:"Category Not found."
                });
            }
        } 
    });    
});
 
//handles url http://localhost:6001/products/delete
router.delete("/deleteCategory/:Category_id", (req, res, next) => {
    var Category_id = parseInt(req.params.Category_id);
 
    db.query(Category.deleteCategoryByIdSQL(Category_id), (err, data)=> {
        if(!err) {
            if(data && data.affectedRows > 0) {
                res.status(200).json({
                    message:`Category deleted with id = ${Category_id}.`,
                    categoryData: data.affectedRows
                });
            } else {
                res.status(200).json({
                    message:"Category Not found."
                });
            }
        } 
    });   
});

router.put("/updateCategory/:Category_id", (req, res, next) => {
    var Category_id = parseInt(req.params.Category_id);    
    let category = new Category(req.body.Category_name,req.body.Category_icon);
 
    db.query(category.getUpdateCategorySQL(Category_id), (err, data)=> {
        if(!err) {
            if(data && data.affectedRows > 0) {
                res.status(200).json({
                    message:`Category update with id = ${Category_id}.`,
                    categoryData: data.affectedRows
                });
            } else {
                res.status(200).json({
                    message:"Category Not found."
                });
            }
        }
    });
});
 
module.exports = router;