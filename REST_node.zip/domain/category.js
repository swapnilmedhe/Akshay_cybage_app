class Category {
    
    constructor(Category_name,Category_icon) {
        this.Category_id=0;
        this.Category_name=Category_name;
        this.Category_icon=Category_icon;
    }
    
    getAddCategorySQL() {
        let sql = `INSERT INTO expensecategory(Category_name, Category_icon) \
                   VALUES('${this.Category_name}', '${this.Category_icon}')`;
        return sql;           
    }
    
    getUpdateCategorySQL(Category_id) {
        let sql = `UPDATE expensecategory SET Category_name = '${this.Category_name}', Category_icon = '${this.Category_icon}' \
                   WHERE Category_id = ${Category_id}`;
        return sql;           
    }
 
    static getCategoryByIdSQL(Category_id) {
        let sql = `SELECT * FROM expensecategory WHERE Category_id = ${Category_id}`;
        return sql;           
    }
 
    static deleteCategoryByIdSQL(Category_id) {
        let sql = `DELETE FROM expensecategory WHERE Category_id = ${Category_id}`;
        return sql;           
    }
 
    static getAllCategorySQL() {
        let sql = `SELECT * FROM expensecategory`;
        return sql;           
    }
}

module.exports = Category;