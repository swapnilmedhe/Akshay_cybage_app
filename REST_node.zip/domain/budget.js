class Budget {
    
    constructor(Transaction_date,Category_id,Description,Amount,IncomeExpense_flag) {
        this.Budget_id=0;
        this.Transaction_date=Transaction_date;
        this.Description=Description;
        this.Amount=Amount;
        this.IncomeExpense_flag=IncomeExpense_flag;
        this.Category_id=Category_id;
    }
 
    getAddBudgetSQL() {
        let sql = `INSERT INTO expenseapp(Transaction_date, Category_id, Description, Amount, IncomeExpense_flag) \
                   VALUES('${this.Transaction_date}', ${this.Category_id}, '${this.Description}', ${this.Amount}, '${this.IncomeExpense_flag}')`;
        return sql;           
    }
    
    getBudgetByDateSQL(Selected_date) {
        console.log(Selected_date);
        console.log(Date.now());
    }
    
    getUpdateBudgetSQL(Budget_id) {
        let sql = `UPDATE expenseapp SET Transaction_date = '${this.Transaction_date}', Description = '${this.Description}', \
                   Amount = ${this.Amount}, IncomeExpense_flag = '${this.IncomeExpense_flag}', Category_id = ${this.Category_id} \
                   WHERE Budget_id = ${Budget_id}`;
        return sql;           
    }
 
    static getBudgetByIdSQL(Budget_id) {
        let sql = `SELECT * FROM expenseapp WHERE Budget_id = ${Budget_id}`;
        return sql;           
    }
 
    static deleteBudgetByIdSQL(Budget_id) {
        let sql = `DELETE FROM expenseapp WHERE Budget_id = ${Budget_id}`;
        return sql;           
    }
 
    static getAllBudgetSQL() {
        let sql = `SELECT * FROM expenseapp`;
        return sql;           
    }
}

module.exports = Budget;